"""
data-wrangler

An data wrangler library
"""

__version__ = "0.1.0"
__author__ = 'Emmanuel Ainoo'
__credits__ = 'Wikipedia'